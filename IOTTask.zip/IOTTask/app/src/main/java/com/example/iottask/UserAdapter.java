package com.example.iottask;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.userHolder> {
    MainActivity mainActivity;
    List<ModelClass> allUserList;

    public UserAdapter(MainActivity mainActivity, List<ModelClass> allUserList) {
        this.mainActivity = mainActivity;
        this.allUserList = allUserList;
    }

    @NonNull
    @Override
    public UserAdapter.userHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new userHolder(LayoutInflater.from(mainActivity).inflate(R.layout.cardlayout,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull UserAdapter.userHolder holder, int position) {

        holder.id.setText(allUserList.get(position).getId());
        holder.name.setText(allUserList.get(position).getName());




    }

    @Override
    public int getItemCount() {
        return allUserList.size();
    }

    public class userHolder extends RecyclerView.ViewHolder {
        ImageView productImage,productBanner;
        TextView id,name,unit,unitParams,price,specialPrice,rating,
                desc,title,offer,offerType,
                disc,manufacturer,categoryname,categoryId,trending,discountProduct,stock,gst,gstRate,status,createdat;
        public userHolder(@NonNull View itemView) {
            super(itemView);
            productImage=itemView.findViewById(R.id.productImage);
            productBanner=itemView.findViewById(R.id.productBannner);
            id=itemView.findViewById(R.id.id);
            name=itemView.findViewById(R.id.name);
            unit=itemView.findViewById(R.id.unit);
            unitParams=itemView.findViewById(R.id.unitParams);
            price=itemView.findViewById(R.id.price);
            specialPrice=itemView.findViewById(R.id.specialPrice);
            rating=itemView.findViewById(R.id.rating);
            desc=itemView.findViewById(R.id.desc);
            rating=itemView.findViewById(R.id.rating);
            title=itemView.findViewById(R.id.title);
            offer=itemView.findViewById(R.id.offer);
            offerType=itemView.findViewById(R.id.offerType);
            disc=itemView.findViewById(R.id.disc);
            manufacturer=itemView.findViewById(R.id.manufacturer);
            categoryname=itemView.findViewById(R.id.categoryName);
            categoryId=itemView.findViewById(R.id.categoryId);
            trending=itemView.findViewById(R.id.trending);
            stock=itemView.findViewById(R.id.stock);
            gst=itemView.findViewById(R.id.gst);
            gstRate=itemView.findViewById(R.id.gstRate);
            status=itemView.findViewById(R.id.status);
            createdat=itemView.findViewById(R.id.createdAt);
            discountProduct=itemView.findViewById(R.id.discountProduct);
        }
    }
}
