package com.example.iottask;

import android.graphics.Bitmap;

import java.util.ArrayList;
import java.util.Date;

public class ModelClass {
    public int id;
    public String name;
    public String unit;
    public String unitParams;
    public int price;
    public int specialPrice;
    public int rating;
    public ArrayList<String> productBannner;
    public String desc;
    public String productImage;
    public String title;
    public int offer;
    public String offerType;
    public String disc;
    public String manufacturer;
    public String categoryName;
    public String categoryId;
    public boolean trending;
    public boolean discountProduct;
    public int stock;
    public String gst;
    public int gstRate;
    public String status;
    public Date createdAt;

    public ModelClass(int id, String name, String unit, String unitParams, int price, int specialPrice, int rating, ArrayList<String> productBannner, String desc, String productImage, String title, int offer, String offerType, String disc, String manufacturer, String categoryName, String categoryId, boolean trending, boolean discountProduct, int stock, String gst, int gstRate, String status, Date createdAt) {
        this.id = id;
        this.name = name;
        this.unit = unit;
        this.unitParams = unitParams;
        this.price = price;
        this.specialPrice = specialPrice;
        this.rating = rating;
        this.productBannner = productBannner;
        this.desc = desc;
        this.productImage = productImage;
        this.title = title;
        this.offer = offer;
        this.offerType = offerType;
        this.disc = disc;
        this.manufacturer = manufacturer;
        this.categoryName = categoryName;
        this.categoryId = categoryId;
        this.trending = trending;
        this.discountProduct = discountProduct;
        this.stock = stock;
        this.gst = gst;
        this.gstRate = gstRate;
        this.status = status;
        this.createdAt = createdAt;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getUnitParams() {
        return unitParams;
    }

    public void setUnitParams(String unitParams) {
        this.unitParams = unitParams;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getSpecialPrice() {
        return specialPrice;
    }

    public void setSpecialPrice(int specialPrice) {
        this.specialPrice = specialPrice;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public ArrayList<String> getProductBannner() {
        return productBannner;
    }

    public void setProductBannner(ArrayList<String> productBannner) {
        this.productBannner = productBannner;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

//    public Bitmap getProductImage() {
//        return productImage;
//    }

    public void setProductImage(String productImage) {
        this.productImage = productImage;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getOffer() {
        return offer;
    }

    public void setOffer(int offer) {
        this.offer = offer;
    }

    public String getOfferType() {
        return offerType;
    }

    public void setOfferType(String offerType) {
        this.offerType = offerType;
    }

    public String getDisc() {
        return disc;
    }

    public void setDisc(String disc) {
        this.disc = disc;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public boolean isTrending() {
        return trending;
    }

    public void setTrending(boolean trending) {
        this.trending = trending;
    }

    public boolean isDiscountProduct() {
        return discountProduct;
    }

    public void setDiscountProduct(boolean discountProduct) {
        this.discountProduct = discountProduct;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public String getGst() {
        return gst;
    }

    public void setGst(String gst) {
        this.gst = gst;
    }

    public int getGstRate() {
        return gstRate;
    }

    public void setGstRate(int gstRate) {
        this.gstRate = gstRate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }
}
